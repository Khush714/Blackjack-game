let deck, playerHand, dealerHand, balance = 1000;
const balanceEl = document.getElementById("balance");
const betEl = document.getElementById("bet");
const playerEl = document.getElementById("player-hand");
const dealerEl = document.getElementById("dealer-hand");
const messageEl = document.getElementById("message");

const dealSound = document.getElementById("deal-sound");
const winSound = document.getElementById("win-sound");
const loseSound = document.getElementById("lose-sound");

function createDeck() {
  const suits = ['H', 'D', 'S', 'C'];
  const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  let deck = [];
  for (let s of suits) {
    for (let v of values) {
      deck.push({ value: v, suit: s });
    }
  }
  return deck.sort(() => Math.random() - 0.5);
}

function getCardValue(card) {
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  if (card.value === 'A') return 11;
  return parseInt(card.value);
}

function calculateHandValue(hand) {
  let total = hand.reduce((sum, card) => sum + getCardValue(card), 0);
  let aces = hand.filter(c => c.value === 'A').length;
  while (total > 21 && aces--) total -= 10;
  return total;
}

function renderHand(hand, container, revealAll = true) {
  container.innerHTML = '';
  hand.forEach((card, i) => {
    const div = document.createElement("div");
    div.className = "card";
    const img = document.createElement("img");
    if (!revealAll && i === 1) {
      img.src = "cards/back.png";
    } else {
      img.src = `cards/${card.value}${card.suit}.png`;
    }
    div.appendChild(img);
    container.appendChild(div);
  });
  dealSound.play();
}

function startGame() {
  const bet = parseInt(betEl.value);
  if (isNaN(bet) || bet <= 0 || bet > balance) {
    alert("Invalid bet");
    return;
  }

  deck = createDeck();
  playerHand = [deck.pop(), deck.pop()];
  dealerHand = [deck.pop(), deck.pop()];

  renderHand(playerHand, playerEl);
  renderHand(dealerHand, dealerEl, false);
  messageEl.textContent = '';

  document.querySelector('.actions').style.display = 'block';
}

function hit() {
  playerHand.push(deck.pop());
  renderHand(playerHand, playerEl);

  const total = calculateHandValue(playerHand);
  if (total > 21) {
    endGame("Bust! You lose.");
    adjustBalance(-parseInt(betEl.value));
    loseSound.play();
  }
}

function stand() {
  document.querySelector('.actions').style.display = 'none';
  while (calculateHandValue(dealerHand) < 17) {
    dealerHand.push(deck.pop());
  }

  const playerTotal = calculateHandValue(playerHand);
  const dealerTotal = calculateHandValue(dealerHand);

  renderHand(dealerHand, dealerEl);

  if (dealerTotal > 21 || playerTotal > dealerTotal) {
    endGame("You win!");
    adjustBalance(parseInt(betEl.value));
    winSound.play();
  } else if (playerTotal < dealerTotal) {
    endGame("Dealer wins.");
    adjustBalance(-parseInt(betEl.value));
    loseSound.play();
  } else {
    endGame("It's a tie.");
  }
}

function endGame(msg) {
  messageEl.textContent = msg;
}

function adjustBalance(amount) {
  balance += amount;
  balanceEl.textContent = balance;
}
