let deck, playerHand, dealerHand, balance = 1000;
const balanceEl = document.getElementById("balance");
const betEl = document.getElementById("bet");
const playerEl = document.getElementById("player-hand");
const dealerEl = document.getElementById("dealer-hand");
const messageEl = document.getElementById("message");

function createDeck() {
  const suits = ['♠', '♥', '♦', '♣'];
  const values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  let deck = [];
  for (let s of suits) {
    for (let v of values) {
      deck.push({ value: v, suit: s });
    }
  }
  return deck.sort(() => Math.random() - 0.5);
}

function getCardValue(card) {
  if (['J', 'Q', 'K'].includes(card.value)) return 10;
  if (card.value === 'A') return 11;
  return parseInt(card.value);
}

function calculateHandValue(hand) {
  let total = hand.reduce((sum, card) => sum + getCardValue(card), 0);
  let aces = hand.filter(c => c.value === 'A').length;
  while (total > 21 && aces--) total -= 10;
  return total;
}

function renderHand(hand, container) {
  container.innerHTML = '';
  for (let card of hand) {
    let div = document.createElement("div");
    div.className = "card";
    div.textContent = `${card.value}${card.suit}`;
    container.appendChild(div);
  }
}

function startGame() {
  const bet = parseInt(betEl.value);
  if (isNaN(bet) || bet <= 0 || bet > balance) {
    alert("Invalid bet");
    return;
  }

  deck = createDeck();
  playerHand = [deck.pop(), deck.pop()];
  dealerHand = [deck.pop(), deck.pop()];

  renderHand(playerHand, playerEl);
  renderHand([dealerHand[0], { value: '?', suit: '?' }], dealerEl);
  messageEl.textContent = '';

  document.querySelector('.actions').style.display = 'block';
}

function hit() {
  playerHand.push(deck.pop());
  renderHand(playerHand, playerEl);

  const total = calculateHandValue(playerHand);
  if (total > 21) {
    endGame("Bust! You lose.");
    adjustBalance(-parseInt(betEl.value));
  }
}

function stand() {
  document.querySelector('.actions').style.display = 'none';
  while (calculateHandValue(dealerHand) < 17) {
    dealerHand.push(deck.pop());
  }

  const playerTotal = calculateHandValue(playerHand);
  const dealerTotal = calculateHandValue(dealerHand);

  renderHand(dealerHand, dealerEl);

  if (dealerTotal > 21 || playerTotal > dealerTotal) {
    endGame("You win!");
    adjustBalance(parseInt(betEl.value));
  } else if (playerTotal < dealerTotal) {
    endGame("Dealer wins.");
    adjustBalance(-parseInt(betEl.value));
  } else {
    endGame("It's a tie.");
  }
}

function endGame(msg) {
  messageEl.textContent = msg;
}

function adjustBalance(amount) {
  balance += amount;
  balanceEl.textContent = balance;
}
